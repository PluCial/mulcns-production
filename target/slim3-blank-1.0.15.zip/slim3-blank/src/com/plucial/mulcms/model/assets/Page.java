package com.plucial.mulcms.model.assets;

import java.io.Serializable;

import org.slim3.datastore.Model;

@Model(schemaVersion = 1)
public class Page extends Assets implements Serializable {

    private static final long serialVersionUID = 1L;
}
