package com.plucial.mulcms.model.widgets.form;

import java.io.Serializable;

import org.slim3.datastore.Model;

@Model(schemaVersion = 1)
public class ReceptionMailAction extends MailAction implements Serializable {

    private static final long serialVersionUID = 1L;

    
}
