package com.plucial.mulcms.dao.widgets.form;

import org.slim3.datastore.DaoBase;

import com.plucial.mulcms.model.widgets.form.SendMailAction;

public class SendMailActionDao extends DaoBase<SendMailAction>{

}
