package com.plucial.mulcms.dao.assets;

import org.slim3.datastore.DaoBase;

import com.plucial.mulcms.model.assets.Assets;

public class AssetsDao extends DaoBase<Assets>{

}
