package com.plucial.mulcms.service.widgets.form;




public class SendMailActionService {
    
    /** DAO */
//    private static final SendMailActionDao dao = new SendMailActionDao();

}
