package com.plucial.mulcms.service.widgets;


public class WidgetService {

}
